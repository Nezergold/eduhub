import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Course, CourseApprovalSubmission, Department, Notification, Registration, Score, SemesterResult, User, View } from "../lib/types";
import {
  addCourse, addDepartment, addRegistration, dropRegistration,
  computeAdminStats, computeEnrollmentByFaculty, computeGPATrend,
  computeGradeDistribution, computePassFailByCourse,
  getCourses, getDepartments, getLecturerCourses, getNotifications,
  getRegistrations, getScores, getSemesterResults, getStudentRegistrations,
  getStudentScores, getUnreadCount, getStudentRegistrationSummary, getRecentScores, initStore,
  markAllNotificationsRead, markNotificationRead,
  submitCourseScores, submitCourseScoresForReview, updateCourseLecturer, updateRegistrationStatus,
  upsertScore, publishCourseScores,
  lecturerReviewRegistration, submitCourseApprovalsToAdmin, getCourseApprovalSubmissions,
  adminReviewCourseSubmission, adminReviewScore, adminReviewAllPendingScores,
  getPendingResultReviews, approveCoursePayment, purgeLecturerReferences,
  addLecturerCourse, removeLecturerCourse,
} from "../lib/store";
import { getAllUsers } from "../lib/auth";
import { updateUser as authUpdateUser, deleteUser as authDeleteUser } from "../lib/auth";

interface AppDataContextValue {
  user: User;
  courses: Course[];
  registrations: Registration[];
  scores: Score[];
  courseApprovalSubmissions: CourseApprovalSubmission[];
  pendingResultReviews: Score[];
  departments: Department[];
  notifications: Notification[];
  unreadCount: number;
  refresh: () => void;
  onNavigate: (view: View) => void;
  // Student
  getMyRegistrations: () => Registration[];
  getMyScores: () => Score[];
  getMySemesterResults: () => SemesterResult[];
  registerForCourse: (course: Course, subjects: string[]) => void;
  dropMyRegistration: (id: string) => void;
  // Lecturer
  getMyCourses: () => Course[];
  addMyCourse: (course: Omit<Course, "id" | "lecturer" | "lecturerId" | "subjects">) => void;
  removeMyCourse: (courseId: string) => void;
  submitScores: (course: Course, entries: Parameters<typeof submitCourseScores>[1], options?: { publish?: boolean }) => void;
  submitScoresForReview: (courseCode: string) => number;
  publishCourseScores: (courseCode: string) => number;
  lecturerApproveRegistration: (id: string, note?: string) => void;
  lecturerRejectRegistration: (id: string, note?: string) => void;
  submitCourseApprovals: (courseId: string) => void;
  approveCoursePayment: (registrationId: string) => boolean;
  reviewResult: (studentId: string, courseCode: string, decision: "approved" | "rejected", note?: string) => void;
  reviewAllPendingResults: (courseCode: string, decision: "approved" | "rejected", note?: string) => number;
  reviewCourseSubmission: (submissionId: string, decision: "approved" | "rejected", note?: string) => void;
  // Admin
  createCourse: (course: Omit<Course, "id">) => Course;
  createDepartment: (name: string, faculty: string) => Department;
  approveRegistration: (id: string) => void;
  rejectRegistration: (id: string) => void;
  assignLecturer: (courseId: string, lecturerId: string, lecturerName: string) => void;
  adminStats: ReturnType<typeof computeAdminStats>;
  gradeDistribution: ReturnType<typeof computeGradeDistribution>;
  passFailData: ReturnType<typeof computePassFailByCourse>;
  enrollData: ReturnType<typeof computeEnrollmentByFaculty>;
  gpaTrend: ReturnType<typeof computeGPATrend>;
  allUsers: User[];
  registrationSummary: ReturnType<typeof getStudentRegistrationSummary>;
  recentScores: ReturnType<typeof getRecentScores>;
  updateUser: (userId: string, input: Parameters<typeof authUpdateUser>[1]) => Promise<{ success: boolean; error?: string; user?: User }>;
  deleteLecturer: (userId: string) => Promise<{ success: boolean; error?: string }>;
  markRead: (id: string) => void;
  markAllRead: () => void;
}

const AppDataContext = createContext<AppDataContextValue | null>(null);

export function AppDataProvider({
  user,
  onNavigate,
  children,
}: {
  user: User;
  onNavigate: (view: View) => void;
  children: ReactNode;
}) {
  const [tick, setTick] = useState(0);
  const refresh = useCallback(() => setTick(t => t + 1), []);

  useEffect(() => {
    initStore();
    const handler = () => refresh();
    const storageHandler = (event: StorageEvent) => {
      if (event.key === "wawuhub_data" || event.key === "wawuhub_users") {
        refresh();
      }
    };
    window.addEventListener("wawuhub:data-changed", handler);
    window.addEventListener("wawuhub:users-changed", handler);
    window.addEventListener("storage", storageHandler);
    return () => {
      window.removeEventListener("wawuhub:data-changed", handler);
      window.removeEventListener("wawuhub:users-changed", handler);
      window.removeEventListener("storage", storageHandler);
    };
  }, [refresh]);

  const courses = useMemo(() => getCourses(), [tick]);
  const registrations = useMemo(() => getRegistrations(), [tick]);
  const scores = useMemo(() => getScores(), [tick]);
  const courseApprovalSubmissions = useMemo(() => getCourseApprovalSubmissions(), [tick]);
  const pendingResultReviews = useMemo(() => getPendingResultReviews(), [tick]);
  const departments = useMemo(() => getDepartments(), [tick]);
  const notifications = useMemo(() => getNotifications(user.id), [tick, user.id]);
  const unreadCount = useMemo(() => getUnreadCount(user.id), [tick, user.id]);
  const allUsers = useMemo(() => getAllUsers(), [tick]);

  const value = useMemo<AppDataContextValue>(() => ({
    user,
    courses,
    registrations,
    scores,
    courseApprovalSubmissions,
    pendingResultReviews,
    departments,
    notifications,
    unreadCount,
    refresh,
    onNavigate,
    getMyRegistrations: () => getStudentRegistrations(user.id),
    getMyScores: () => getStudentScores(user.id),
    getMySemesterResults: () => getSemesterResults(user.id),
    registerForCourse: (course, subjects) => {
      addRegistration(user, course, subjects);
      refresh();
    },
    dropMyRegistration: (id) => {
      dropRegistration(id, user.id);
      refresh();
    },
    getMyCourses: () => getLecturerCourses(user),
    addMyCourse: (course) => {
      addLecturerCourse(user, course);
      refresh();
    },
    removeMyCourse: (courseId) => {
      removeLecturerCourse(user, courseId);
      refresh();
    },
    submitScores: (course, entries, options) => {
      submitCourseScores(course, entries, user, options);
      refresh();
    },
    submitScoresForReview: (courseCode) => {
      const count = submitCourseScoresForReview(courseCode, user);
      refresh();
      return count;
    },
    publishCourseScores: (courseCode) => {
      const count = publishCourseScores(courseCode, user.name);
      refresh();
      return count;
    },
    lecturerApproveRegistration: (id, note) => {
      lecturerReviewRegistration(id, "approved", note);
      refresh();
    },
    lecturerRejectRegistration: (id, note) => {
      lecturerReviewRegistration(id, "rejected", note);
      refresh();
    },
    submitCourseApprovals: (courseId) => {
      submitCourseApprovalsToAdmin(courseId, user);
      refresh();
    },
    approveCoursePayment: (registrationId) => {
      const ok = approveCoursePayment(registrationId, user);
      if (ok) refresh();
      return ok;
    },
    reviewResult: (studentId, courseCode, decision, note) => {
      adminReviewScore(studentId, courseCode, decision, user.name, note);
      refresh();
    },
    reviewAllPendingResults: (courseCode, decision, note) => {
      const count = adminReviewAllPendingScores(courseCode, decision, user.name, note);
      refresh();
      return count;
    },
    reviewCourseSubmission: (submissionId, decision, note) => {
      adminReviewCourseSubmission(submissionId, decision, user.name, note);
      refresh();
    },
    createCourse: (course) => {
      const c = addCourse(course);
      refresh();
      return c;
    },
    createDepartment: (name, faculty) => {
      const d = addDepartment(name, faculty);
      refresh();
      return d;
    },
    approveRegistration: (id) => { updateRegistrationStatus(id, "approved"); refresh(); },
    rejectRegistration: (id) => { updateRegistrationStatus(id, "rejected"); refresh(); },
    assignLecturer: (courseId, lecturerId, lecturerName) => {
      updateCourseLecturer(courseId, lecturerId, lecturerName);
      refresh();
    },
    adminStats: computeAdminStats(),
    gradeDistribution: computeGradeDistribution(),
    passFailData: computePassFailByCourse(),
    enrollData: computeEnrollmentByFaculty(),
    gpaTrend: computeGPATrend(),
    allUsers,
    registrationSummary: getStudentRegistrationSummary(),
    recentScores: getRecentScores(12),
    updateUser: async (userId, input) => {
      const result = await authUpdateUser(userId, input);
      if (result.success) refresh();
      return { success: result.success, error: result.error, user: result.user };
    },
    deleteLecturer: async (userId) => {
      const target = getAllUsers().find(u => u.id === userId);
      if (!target) return { success: false, error: "Lecturer not found." };
      if (target.role !== "lecturer") return { success: false, error: "Only lecturer accounts can be removed here." };
      purgeLecturerReferences(target.id, target.name);
      const result = await authDeleteUser(userId);
      if (result.success) refresh();
      return { success: result.success, error: result.error };
    },
    markRead: (id) => { markNotificationRead(id); refresh(); },
    markAllRead: () => { markAllNotificationsRead(user.id); refresh(); },
  }), [user, courses, registrations, scores, courseApprovalSubmissions, pendingResultReviews, departments, notifications, unreadCount, refresh, onNavigate, allUsers, tick]);

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData(): AppDataContextValue {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error("useAppData must be used within AppDataProvider");
  return ctx;
}

export { upsertScore };
